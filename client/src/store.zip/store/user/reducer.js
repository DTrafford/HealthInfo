import * as actionTypes from './action';


const initState = {
    user: {
        isAuthenticated: false,
        shouldRedirect: false,
        user: null,
        userType: null,
        patientList: null,
        healthTips: null,
        loadedResults: null,
        conditions: null,
    },
}

export function user(state = initState, action) {
    console.log(action);
    switch (action.type) {
        case actionTypes.LOGIN:
        let userType = '';
            if(action.user.data.designation) {
                userType = 'EM';
            } else {
                userType = 'PT';
            }
            return {
                ...state,
                isAuthenticated: true,
                shouldRedirect: true,
                user: action.user.data,
                userType: userType
            }
        case actionTypes.LOGOUT:
            return {
                ...state,
                isAuthenticated: false,
                shouldRedirect: true,
                user: null,
                userType: null
            }
        case actionTypes.GETPATIENTS:
            console.log(action);
            return {
                ...state,
                patientList: action.patients.data.patients
            }
        case actionTypes.GETPATIENT:
            console.log('GET PATIENT ACTION = ', action);
            return {
                ...state,
                loadedResults: action.patient.data.healthData
            }
        case actionTypes.CREATETIP:
            console.log(action);
            return {
                ...state,
            }
        case actionTypes.GETTIPS:
        console.log('GET TIPS ACTION ', action);
            return {
                ...state,
                healthTips: action.tips.data.tips
            }
        case actionTypes.DELETETIP:
            // const updatedArray = state.healthTips;
            // updatedArray.splice(state.healthTips.indexOf(action.tip), 1)
            state.healthTips.splice(state.healthTips.indexOf(action.tip), 1);
            console.log(state.healthTips);
            return {
                ...state,
                healthTips: state.healthTips
            }
        case actionTypes.GETCONDITIONS:
        console.log('GET CONDITIONS ACTION ', action);
            return {
                ...state,
                conditions: action.conditions.data.conditions
            }
        default: 
            return state;
        }
}
