export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";
export const GETPATIENTS = 'GETPATIENTS';
export const GETPATIENT = 'GETPATIENT';
export const CREATETIP = 'CREATETIP';
export const GETTIPS = 'GETTIPS';
export const DELETETIP = 'DELETETIP';
export const GETCONDITIONS = 'GETCONDITIONS';